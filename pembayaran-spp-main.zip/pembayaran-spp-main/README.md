# pembayaran-spp laravel 8
Untuk menjalankan project :
1. composer update
2. php artisan key:generate
3. php artisan migrate --seed
4. php artisan serve

email dan password bisa dilihat di direktori databaseseeders
