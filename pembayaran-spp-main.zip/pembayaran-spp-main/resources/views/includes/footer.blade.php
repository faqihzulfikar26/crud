<footer class="main-footer">
  <div class="footer-left">
    Copyright &copy; 2022 <div class="bullet"></div> SPP SMKIU | Rizki & Rifky
  </div>
  <div class="footer-right">
    V.1
  </div>
</footer>
